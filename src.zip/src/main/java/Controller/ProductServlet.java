package Controller;

import DAO.ProductDAO;
import DAO.StoreDAO;
import Model.LoggedUser;
import Model.Product;
import Model.Store;
import Service.AccessService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

@WebServlet("/products")
public class ProductServlet extends HttpServlet {

    private final ProductDAO dao = new ProductDAO();
    private final StoreDAO storeDAO = new StoreDAO();

    @Override
    protected void doGet(HttpServletRequest req,  HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");

        String action = req.getParameter("action");
        LoggedUser user = AccessService.currentUser(req);

        try {

            if ("new".equals(action)){
                //Load stores for the product form
                req.setAttribute("stores", storeDAO.readStores().stream()
                        .filter(s -> AccessService.canAccessRegion(user, s.getRegionTypeId()))
                        .toList());
                req.getRequestDispatcher("/crud-product.jsp").forward(req, resp);
            }

            else if ("edit".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                Product product = dao.searchById(id);

                if (product == null || !AccessService.canAccessRegion(user, product.getRegionTypeId())) {
                    resp.sendError(HttpServletResponse.SC_NOT_FOUND, "Produto não encontrado");
                    return;
                }

                req.setAttribute("product", product);
                req.getRequestDispatcher("/crud-product.jsp").forward(req, resp);
            }

            else {
                req.setAttribute("products", dao.select(AccessService.scope(user)));
                req.getRequestDispatcher("/WEB-INF/views/products.jsp").forward(req, resp);
            }
        } catch (SQLException e){
            throw new ServletException("Erro ao buscar produtos", e);
        } catch (IllegalArgumentException e) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID inválido");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req,  HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");

        String action = req.getParameter("action");
        LoggedUser user = AccessService.currentUser(req);
        if (action == null) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Ação inválida");
            return;
        }
        try {

            switch (action) {

                case "new": add(req, resp, user); break;
                case "edit": update(req, resp, user); break;
                case "delete": delete(req, resp, user); break;
                default: resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Ação inválida");

            }
        } catch (SQLException e){
            throw new ServletException("Erro ao salvar produto", e);
        } catch (IllegalArgumentException | DateTimeParseException e) {
            req.setAttribute("erro", e instanceof DateTimeParseException
                    ? "Informe uma data de validade válida."
                    : e instanceof NumberFormatException
                    ? "Informe preço, quantidade e loja válidos." : e.getMessage());
            try {
                req.setAttribute("products", dao.select(AccessService.scope(user)));
                req.getRequestDispatcher("/WEB-INF/views/products.jsp").forward(req, resp);
            } catch (SQLException ex) {
                throw new ServletException("Erro ao buscar produtos", ex);
            }
        }
    }

    private void add(HttpServletRequest req, HttpServletResponse resp, LoggedUser user)
            throws SQLException, IOException {
        Product  product = new Product();

        product.setName(req.getParameter("name"));
        product.setPrice(Double.parseDouble(requiredParameter(req, "price")));
        product.setQuantity(Integer.parseInt(requiredParameter(req, "quantity")));
        product.setBatch(req.getParameter("batch"));
        product.setExpirationDate(LocalDate.parse(requiredParameter(req, "expirationDate")));
        product.setStore_id(Integer.parseInt(requiredParameter(req, "store_id")));
        product.setLine(req.getParameter("line"));
        product.setBrand(req.getParameter("brand"));

        validate(product);
        Store store = storeDAO.foundStore(product.getStore_id());
        if (store == null || !AccessService.canAccessRegion(user, store.getRegionTypeId())) {
            throw new IllegalArgumentException("Loja inválida");
        }

        dao.insert(product);

        resp.sendRedirect(req.getContextPath() + "/products");
    }

    private void delete(HttpServletRequest req, HttpServletResponse resp, LoggedUser user)
            throws SQLException, IOException {
        Product product = new Product();
        int id = Integer.parseInt(req.getParameter("id"));

        Product existing = dao.searchById(id);
        if (existing == null || !AccessService.canAccessRegion(user, existing.getRegionTypeId())) {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND, "Produto não encontrado");
            return;
        }

        product.setId(id);

        dao.delete(product);

        resp.sendRedirect(req.getContextPath() + "/products");
    }

    private void update (HttpServletRequest req, HttpServletResponse resp, LoggedUser user)
            throws SQLException, IOException{
        Product product = new Product();

        int id = Integer.parseInt(req.getParameter("id"));
        Product existing = dao.searchById(id);
        if (existing == null || !AccessService.canAccessRegion(user, existing.getRegionTypeId())) {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND, "Produto não encontrado");
            return;
        }

        product.setId(id);
        product.setName(req.getParameter("name"));
        product.setBatch(req.getParameter("batch"));
        product.setBrand(req.getParameter("brand"));
        product.setLine(req.getParameter("line"));
        product.setExpirationDate(LocalDate.parse(requiredParameter(req, "expirationDate")));
        product.setQuantity(Integer.parseInt(requiredParameter(req, "quantity")));
        product.setPrice(Double.parseDouble(requiredParameter(req, "price")));

        validate(product);
        validateText(product.getBrand(), "Marca");
        validateText(product.getLine(), "Linha");

        dao.update(product);

        resp.sendRedirect(req.getContextPath() + "/products");
    }

    //check required fields before saving the product
    private void validate(Product product) {
        validateAlphaText(product.getName(), "Nome");
        validateText(product.getBrand(), "Marca");
        validateText(product.getLine(), "Linha");
        if (product.getBatch() == null || !product.getBatch().matches("^[0-9]{1,50}$")) {
            throw new IllegalArgumentException("Lote inválido: informe apenas números (até 50 dígitos).");
        }
        if (!Double.isFinite(product.getPrice()) || product.getPrice() < 0) {
            throw new IllegalArgumentException("Informe um preço válido maior ou igual a zero.");
        }
        if (product.getQuantity() < 0) {
            throw new IllegalArgumentException("Informe uma quantidade válida maior ou igual a zero.");
        }
    }

    private void validateText(String value, String field) {
        validateAlphaText(value, field);
    }

    //regex method, accepts digits [0-9], and limits to 50 characters
    private void validateAlphaText(String value, String field) {
        if (value == null || !value.trim().matches("^[\\p{L}]+(?: +[\\p{L}]+)*$")) {
            throw new IllegalArgumentException("Campo " + field + " inválido: use somente letras e espaços.");
        }
    }

    //method to require all fields to be filled
    private String requiredParameter(HttpServletRequest req, String name) {
        String value = req.getParameter(name);
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Preencha todos os campos antes de salvar.");
        }
        return value;
    }
}
