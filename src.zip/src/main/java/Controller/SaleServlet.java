package Controller;

import DAO.SaleDAO;
import DAO.ProductDAO;
import Model.LoggedUser;
import Model.Sale;
import Service.AccessService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.DateTimeException;

@WebServlet("/sales")
public class SaleServlet extends HttpServlet {
    private final SaleDAO saleDAO = new SaleDAO();
    private final ProductDAO productDAO = new ProductDAO();

    //only show information that belongs the logged user
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        try {
            Integer scope = AccessService.scope(AccessService.currentUser(req));
            req.setAttribute("itens", saleDAO.select(scope));
            req.setAttribute("produtos", productDAO.select(scope));
            req.getRequestDispatcher("/WEB-INF/views/promocao.jsp").forward(req, resp);
        } catch (SQLException e) {
            throw new ServletException("Erro ao consultar promocoes", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String action = req.getParameter("action");
        LoggedUser user = AccessService.currentUser(req);
        if (action == null || !(action.equals("add") || action.equals("edit") || action.equals("delete"))) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Ação inválida");
            return;
        }

        try {
            Sale sale = new Sale();
            if (!"add".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                sale = saleDAO.searchById(id);
                if (sale == null || !AccessService.canAccessProduct(user, sale.getProductId())) {
                    resp.sendError(HttpServletResponse.SC_NOT_FOUND, "Promoção não encontrada");
                    return;
                }
            }

            //validate form values before creating the sale
            if (!"delete".equals(action)) {
                int productId = readProductId(req);
                if (productId <= 0 || !AccessService.canAccessProduct(user, productId)) {
                    throw new IllegalArgumentException("Selecione um produto válido.");
                }
                sale.setProductId(productId);
                sale.setDiscountPercentage(readDiscount(req));
                sale.setPromotionValidUntil(readValidUntil(req));
                LocalDate from = "add".equals(action) ? LocalDate.now() : sale.getSugestionDate();
                if (!Double.isFinite(sale.getDiscountPercentage()) || sale.getDiscountPercentage() <= 0
                        || sale.getDiscountPercentage() > 100) {
                    throw new IllegalArgumentException("Informe um desconto válido, maior que zero e até 100%.");
                }
                if (from != null && sale.getPromotionValidUntil().isBefore(from)) {
                    throw new IllegalArgumentException("A validade deve ser igual ou posterior ao início da promoção.");
                }
            }

            switch (action) {

                case "add": saleDAO.insert(sale); break;
                case "edit": saleDAO.update(sale); break;
                case "delete": saleDAO.delete(sale); break;
                default: return;

            }
            resp.sendRedirect(req.getContextPath() + "/sales");
          //checks expiration date, and discount value
        } catch (IllegalArgumentException | DateTimeException e) {
            req.setAttribute("erro", e instanceof DateTimeException || e instanceof NumberFormatException ? "Confira os dados da promoção." : e.getMessage());
            doGet(req, resp);
        } catch (SQLException e) {
            //foreign key violation, product doesn't exist
            if ("23503".equals(e.getSQLState())) {
                req.setAttribute("erro", "Produto inexistente ou promoção com registros vinculados.");
                doGet(req, resp);
              //check restriction from db, expiration date is invalid
            } else if ("23514".equals(e.getSQLState())) {
                req.setAttribute("erro", "Confira o desconto e a validade: a data final deve ser igual ou posterior ao início da promoção.");
                doGet(req, resp);
            } else {
                throw new ServletException("Erro ao salvar promocao", e);
            }
        }
    }


    private int readProductId(HttpServletRequest req) {
        try {
            return Integer.parseInt(req.getParameter("product-id"));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Selecione um produto válido.");
        }
    }

    private double readDiscount(HttpServletRequest req) {
        try {
            return Double.parseDouble(req.getParameter("discountPercentage"));
        } catch (NullPointerException | NumberFormatException e) {
            throw new IllegalArgumentException("Informe um desconto válido, maior que zero e até 100%.");
        }
    }

    private LocalDate readValidUntil(HttpServletRequest req) {
        try {
            return LocalDate.parse(req.getParameter("promotion-valid-until"));
        } catch (NullPointerException | DateTimeException e) {
            throw new IllegalArgumentException("Informe uma data de validade válida.");
        }
    }
}
